import {Component} from '@angular/core';
@Component({
selector:'employee-info',
template:`
<h2>Employee Info</h2>
<p>Id:{{id}}</p>
<p>Name:{{name}}</p>
<p>Email:{{email}}</p>
`
})
export class EmployeeComponent{
    id:number=36937;
    name:string="prakash venignandla";
    email:string="prakashv@hexaware.com";
}