import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import {EmployeeComponent} from './employee/employee.component';
import { ProductListComponent } from "./products/product-list.component";
import {RouterModule} from '@angular/router';
import { ProductComponent } from './product/product.component';
@NgModule({
  declarations: [
    AppComponent,EmployeeComponent,ProductListComponent, ProductComponent
  ],
  imports: [
    RouterModule.forRoot([
{path:'employee',component:EmployeeComponent},
{path:'products',component:ProductListComponent},
{path:'productdetail/:id',component:ProductComponent},
{path:'',component:EmployeeComponent},
{path:'**',component:EmployeeComponent}
    ]),
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
