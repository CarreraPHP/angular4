import { Product } from "./product";
import { Injectable } from "@angular/core";
import {Http,Response} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
@Injectable()
export class ProductService {
    productsApiUrl="/app/api/products.json";
    constructor(private http:Http){}
    getProducts():Observable<Product[]>{
        return this.http.get(this.productsApiUrl)
        .map((response:Response)=><Product[]>response.json())
        .do((data)=>console.log(data))
        .catch(this.handleError);
    }
    private handleError(error:Response):any{}
}