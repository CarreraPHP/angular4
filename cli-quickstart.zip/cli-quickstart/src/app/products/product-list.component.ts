import { Component } from "@angular/core";
import { Product } from "./product";
import { ProductService } from "./product.service";
@Component({
selector:'product-list',
templateUrl:"./product-list.component.html"
})
export class ProductListComponent {
    error:any;
    constructor(private productService:ProductService){
    this.productService.getProducts()
    .subscribe((products)=>this.products=products,
    (error)=>this.error=error);
    }
    showImage:boolean=false;
    toggleImages():void{
    this.showImage=!this.showImage;
    }
    products: Product[]; 
}