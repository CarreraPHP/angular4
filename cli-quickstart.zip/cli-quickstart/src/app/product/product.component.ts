import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
id:number;
name:string;
price:number;
  constructor(private activatedRoute:ActivatedRoute,
  private router:Router) {
    this.id=this.activatedRoute.snapshot.params['id'];
    this.name=this.activatedRoute.snapshot.params['name'];
    this.price=this.activatedRoute.snapshot.queryParams['price'];
   }
   onBackButton(){
  this.router.navigate(['/products']);
   }
  ngOnInit() {
    
  }

}
