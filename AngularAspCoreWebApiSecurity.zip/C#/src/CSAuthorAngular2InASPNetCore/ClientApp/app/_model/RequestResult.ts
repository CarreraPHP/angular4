﻿export class RequestResult {
    State: number;
    Msg: string;
    Data: Object;
}