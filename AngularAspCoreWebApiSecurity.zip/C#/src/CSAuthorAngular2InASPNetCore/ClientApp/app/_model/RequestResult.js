"use strict";
var RequestResult = (function () {
    function RequestResult() {
    }
    return RequestResult;
}());
exports.RequestResult = RequestResult;
//# sourceMappingURL=RequestResult.js.map