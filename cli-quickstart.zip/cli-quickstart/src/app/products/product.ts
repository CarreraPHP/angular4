export class Product{
    id:number;
    name:string;
    price:number;
    rating:number;
    imageUrl:string;
    imageHeight:number;
    imageWidth:number;
    mfg:Date;
}